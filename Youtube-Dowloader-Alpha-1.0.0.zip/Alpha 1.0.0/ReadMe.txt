Yt-Dlp Based Dowloader | Version: Alpha 1.0.0 | Author: HaloGamer 33

English

Instructions:

	1 - Right click the "Youtube-Dlp-Gui.ps1" and select the second option "Run with PowerShell"
	
	2 - A "directive change" prompt might pop up in the PowerShell terminal, just select "Yes to all" to continue.
	
	3 - Copy and paste a YouTube link to the terminal prompt, and use the numbers + enter to navigate the Gui.

Spanish

Instrucciones: 

	1 - Haz click derecho en el archivo "Youtube-Dlp-Gui.ps1" y selecciona la segunda opción "Ejecutar con PowerShell"
	
	2 - Es probable que un "cambio de directiva" aparezca, solo selecciona "Si a todo" para continuar.

	3 - Copia y pega un link de YouTube hacia el terminal, usa los numeros + enter para navegar la interfaz grafica.